<?php
// database config
$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "simple_blog_app";

// create database connection
$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn -> connect_error){
  die("connection failed: " . $con -> connect_error);
}
?>